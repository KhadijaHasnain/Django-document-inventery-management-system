from django.apps import AppConfig


class InventoryManagerConfig(AppConfig):
    name = 'item'
